const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

router.get('/:residenteId', (req, res) => {
  console.log(`[Backend] Recibida petición para residenteId: ${req.params.residenteId}`);

  const facturasFilePath = path.join(__dirname, '../data/facturas.json');

  if (!fs.existsSync(facturasFilePath)) {
    console.error(`[Backend ERROR] El archivo facturas.json no se encontró en: ${facturasFilePath}`);
    return res.status(500).json({ message: 'Archivo de facturas no encontrado en el servidor.' });
  }

  try {
    const rawData = fs.readFileSync(facturasFilePath, 'utf8');
    const facturas = JSON.parse(rawData);

    const residentesFacturas = facturas.filter(f => String(f.residenteId) === String(req.params.residenteId));
    
    console.log(`[Backend] Facturas encontradas para residenteId ${req.params.residenteId}:`);
    // ¡NUEVO CONSOLE.LOG CRÍTICO!
    // Imprime cada objeto de factura tal como se va a enviar al frontend
    residentesFacturas.forEach((factura, index) => {
      console.log(`[Backend] Factura ${index + 1}:`, factura);
    });

    res.json(residentesFacturas);
  } catch (error) {
    console.error(`[Backend ERROR] Error al procesar facturas.json: ${error.message}`);
    res.status(500).json({ message: 'Error al procesar los datos de las facturas.' });
  }
});

module.exports = router;
