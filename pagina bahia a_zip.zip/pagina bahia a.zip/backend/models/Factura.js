class Factura {
  constructor(id, residenteId, fecha, monto, estado, concepto_factura) {
    this.id = id;
    this.residenteId = residenteId;
    this.fecha = fecha;
    this.monto = monto;
    this.estado = estado;
    this.concepto_factura = concepto_factura || "Administración";
  }
}
module.exports = Factura;
