import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function PanelResidente({ residente, onLogout }) {
  const [facturas, setFacturas] = useState([]);

  useEffect(() => {
    // Esta llamada API ahora debería devolver el campo 'concepto_factura' correctamente
    axios
      .get(`http://localhost:3001/api/facturas/${residente.id}`)
      .then((res) => {
        setFacturas(res.data);
        // Nuevo console.log para ver qué datos se están estableciendo
        console.log("Datos de facturas recibidos y establecidos en el estado:", res.data);
      })
      .catch((error) => {
        console.error("Error al obtener facturas:", error);
        // Manejo de errores
      });
  }, [residente.id]);

  // Función para generar el recibo de facturas pagadas
  function generarReciboPagados(facturas, residente) {
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    const pagadas = facturas.filter((f) => f.estado === "pagada");

    // Usa f.concepto_factura para el PDF de pagados
    const conceptos = pagadas.map((f) => [
      `${f.concepto_factura || "Administracion"} ${
        f.fecha?.slice(0, 7) || ""
      } (${f.depto || residente.depto})`,
      Number(f.monto || 0),
    ]);

    const totalPagado = conceptos.reduce((sum, c) => sum + c[1], 0);
    const fechaGenerada = new Date().toISOString().slice(0, 10);

    function bloquePagados(x) {
      doc.setFontSize(10);
      doc.text("Recibo de Pagos Realizados", x + 40, 18);
      doc.setFontSize(8);
      doc.text("C. Residencial Santa Maria Del Buen Aire P.H.", x + 5, 25);
      doc.text("NIT: 900.202.865-6", x + 5, 29);
      doc.text("Calle 49 # 17 C -80", x + 5, 33);
      doc.text("facturacion@ambientehorizontal.com", x + 5, 37);

      doc.text(`Generada el: ${fechaGenerada}`, x + 5, 43);
      doc.text(`Propietario: ${residente.nombre}`, x + 5, 47);
      doc.text(`Inmueble: ${residente.depto}`, x + 50, 47);

      autoTable(doc, {
        startY: 53,
        margin: { left: x + 5 },
        head: [["Concepto", "Pagado"]],
        body: conceptos.map(([concepto, valor]) => [
          concepto,
          Number(valor).toLocaleString("es-CO"),
        ]),
        theme: "grid",
        styles: { fontSize: 8, cellPadding: 1, halign: "right" },
        headStyles: { fillColor: [220, 220, 220], halign: "left" },
        columnStyles: { 0: { halign: "left" }, 1: { halign: "right" } },
      });

      const y = 53 + conceptos.length * 8 + 10;

      doc.setFontSize(10);
      doc.text("Total Pagado", x + 5, y);
      doc.setFont("Helvetica", "bold");
      doc.text(
        Number(totalPagado).toLocaleString("es-CO"),
        x + 60,
        y,
        { align: "right" }
      );
      doc.setFont("Helvetica", "normal");

      doc.setFontSize(7);
      doc.text(
        "Recuerde reportar sus pagos al correo electrónico facturacion@ambientehorizontal.com",
        x + 5,
        y + 7
      );

      doc.setFontSize(8);
      doc.text("Facturado por: Aplicamos CO S.A.S.", x + 5, y + 14);
    }

    bloquePagados(10);

    doc.save(
      `recibo_pagados_${
        residente.nombre?.replace(/ /g, "_") || "Residente"
      }_${fechaGenerada}_${residente.depto}.pdf`
    );
  }

  // Función para generar el recibo de facturas pendientes
  function generarReciboPendiente(facturas, residente) {
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    const pendientes = facturas.filter((f) => f.estado === "pendiente");
    // Usa f.concepto_factura para el PDF de pendientes
    const conceptos = pendientes.map((f) => [
      `${f.concepto_factura || "Administración"} ${
        f.fecha?.slice(0, 7) || ""
      } (${f.depto || residente.depto})`,
      Number(f.monto || 0),
    ]);
    const totalPendiente = conceptos.reduce((sum, c) => sum + c[1], 0);
    const fechaGenerada = new Date().toISOString().slice(0, 10);

    function bloquePendiente(x) {
      doc.setFontSize(10);
      doc.text("Recibo de Pendientes", x + 45, 18);
      doc.setFontSize(8);
      doc.text("C. Residencial Santa Maria Del Buen Aire P.H.", x + 5, 25);
      doc.text("NIT: 900.202.865-6", x + 5, 29);
      doc.text("Calle 49 # 17 C -80", x + 5, 33);
      doc.text("facturacion@ambientehorizontal.com", x + 5, 37);

      doc.text(`Generada el: ${fechaGenerada}`, x + 5, 43);
      doc.text(`Propietario: ${residente.nombre}`, x + 5, 47);
      doc.text(`Inmueble: ${residente.depto}`, x + 50, 47);

      autoTable(doc, {
        startY: 53,
        margin: { left: x + 5 },
        head: [["Concepto", "Pendiente"]],
        body: conceptos.map(([concepto, valor]) => [
          concepto,
          Number(valor).toLocaleString("es-CO"),
        ]),
        theme: "grid",
        styles: { fontSize: 8, cellPadding: 1, halign: "right" },
        headStyles: { fillColor: [220, 220, 220], halign: "left" },
        columnStyles: { 0: { halign: "left" }, 1: { halign: "right" } },
      });

      const y = 53 + conceptos.length * 8 + 10;

      doc.setFontSize(10);
      doc.text("Total Pendiente a Pagar", x + 5, y);
      doc.setFont("Helvetica", "bold");
      doc.text(
        Number(totalPendiente).toLocaleString("es-CO"),
        x + 60,
        y,
        { align: "right" }
      );
      doc.setFont("Helvetica", "normal");

      doc.setFontSize(7);
      doc.text(
        "Recuerde reportar sus pagos al correo electrónico facturacion@ambientehorizontal.com",
        x + 5,
        y + 7
      );

      doc.setFontSize(8);
      doc.text("Facturado por: Aplicamos CO S.A.S.", x + 5, y + 14);
    }

    bloquePendiente(10);

    doc.save(
      `recibo_pendientes_${
        residente.nombre?.replace(/ /g, "_") || "Residente"
      }_${fechaGenerada}_${residente.depto}.pdf`
    );
  }

  return (
    <div className="app-container">
      <div className="header">
        <div>
          <h2>Bienvenido, {residente.nombre}</h2>
          <div>
            Depto: {residente.depto} | Email: {residente.email}
          </div>
        </div>
        <button className="logout" onClick={onLogout}>
          Cerrar sesión
        </button>
      </div>
      <h3>Mis facturas</h3>
      <table>
        <thead>
          <tr>
            <th>Fecha</th>
            <th>Concepto</th>
            <th>Monto</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {facturas.map((f) => {
            // Agregamos un console.log para depurar el valor de concepto_factura
            console.log(`Factura ID: ${f.id}, Concepto recibido: "${f.concepto_factura}"`);
            return (
              <tr key={f.id}>
                <td>{f.fecha}</td>
                {/* Esta línea es la clave para mostrar el concepto del CSV */}
                <td>{f.concepto_factura || "Administración"}</td>
                <td>${f.monto}</td>
                <td>{f.estado === "pagada" ? "Pagada" : "Pendiente"}</td>
                <td>
                  {f.estado === "pagada" && (
                    <button
                      onClick={() => generarReciboPagados(facturas, residente)}
                    >
                      Recibo de Pagos PDF
                    </button>
                  )}
                  {f.estado === "pendiente" && (
                    <button
                      onClick={() => generarReciboPendiente(facturas, residente)}
                    >
                      Recibo de Pendientes PDF
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <h3>
        Total pendiente: ${" "}
        {facturas
          .filter((f) => f.estado === "pendiente")
          .reduce((sum, f) => sum + f.monto, 0)}
      </h3>
    </div>
  );
}
