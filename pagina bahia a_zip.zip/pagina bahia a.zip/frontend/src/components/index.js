export { default as Login } from './Login';
export { default as PanelResidente } from './PanelResidente';
export { default as PanelAdmin } from './PanelAdmin';
